# Attribution

Game code, icon drawings, hamster pixel art, maze artwork and result-card drawing are original to Squeek Maze Sprint, under the repository MIT license.

Silkscreen is Copyright 2001 The Silkscreen Project Authors, SIL Open Font License 1.1. The complete notice and license are bundled at `public/licenses/silkscreen-OFL.txt` and `dist/licenses/silkscreen-OFL.txt`. Its WOFF2 is supplied by the pinned `@fontsource/silkscreen` package. System sans-serif fallbacks are supplied by the visitor's operating system.

Design/review guidance was adapted from [Jakub Krehel's Better Interface](https://github.com/jakubkrehel/skills/tree/267330e1adfc66a718fb65fa6918c1f06d0a689e/skills/better-interface), commit `267330e1adfc66a718fb65fa6918c1f06d0a689e`, MIT. Documentation method: [Paul Bakaus's Impeccable](https://github.com/pbakaus/impeccable/blob/9d715cc4f5564a990ca8345abfdd5df6dc9b41c8/skill/reference/document.md), commit `9d715cc4f5564a990ca8345abfdd5df6dc9b41c8`, Apache-2.0. The supplied combined license is retained at `artifacts/licenses/design-guidance.txt`. These are design references, not runtime dependencies or independent certification of the game.

Live chain and wheel data comes from [Squeekchain's public API](https://docs.squeekchain.com/developers/api/). Squeekchain's project and animal are not controlled by this application. The test fixtures are clearly named frozen extracts from the official API on 4 November 2026; runtime code never imports them. No third-party artwork, photos, token images, or logos are reused.

React, React DOM and Vite are MIT licensed. TypeScript is Apache-2.0. Their exact versions, integrity information and dependency license metadata are in `package-lock.json`; browser/test tools are development dependencies. No dependency directory, registry mirror or package tarball is included in the submission.
