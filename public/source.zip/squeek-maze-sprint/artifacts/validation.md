# Validation record: revision 2

These are the worker's own results on its own machine, not independent certification.

## Review findings handled in this revision

| Finding | Reproduced | Change |
| --- | --- | --- |
| Landscape phone layout splits the maze and the touch controls | Yes. On the previous export at 844×390, the board was 560×560 from y202 to y762, Start was at y537–585 and the d-pad at y840–932. At 852×393 the board was 149×149 and the d-pad was not displayed. | `src/styles.css`: added a short-landscape rule: `(orientation: landscape) and (max-height: 33.75rem)`, or a landscape coarse pointer up to 56rem high. In that mode, the HUD is in a left column. The square board is sized from the remaining height. The signal strip, modifier help and d-pad are in a right column. The rail is hidden and `.game-shell` has no height-derived max width. A coarse pointer at 53rem or wider keeps the d-pad visible under the board. The d-pad and direction styles moved out of the phone breakpoint so both modes can use them. |
| Singular result counts read "1 Squeeks" / "1 bumps" | Yes, by reading the code at `src/share.ts:13`, `src/share.ts:28` and `src/App.tsx:245`. | Added `countLabel`/`resultCounts` in `src/share.ts`. The result overlay, the copied share text, the PNG card and the live status message all use them now. |

Board, Start button and d-pad positions on the rebuilt export, with official API requests aborted (labelled demo), touch enabled:

| Viewport | Board (y range, size) | Start bottom | D-pad (y range) |
| --- | --- | --- | --- |
| 667×375 | 54–307, 253px | 238 | 230–322 |
| 844×390 | 54–372, 318px | 251 | 280–372 |
| 852×393 | 54–375, 321px | 253 | 283–375 |
| 932×430 | 54–412, 358px | 271 | 320–412 |
| 1024×768 touch | 54–664, 610px | 397 | 572–664 |
| 1366×1024 touch | 198–822, 624px | 613 | 900–992 |
| 1440×900 touch | 198–698, 500px | 551 | 776–868 |
| 390×844 | 190–548, 358px | 458 | 612–704 (unchanged) |

Non-touch 1440×900, 1280×720 and 1024×768 keep the previous desktop layout with the rail and no d-pad.

## Commands and results (final source)

- `npm run typecheck`: passed, no errors.
- `npm test`: 20/20 passed, including the new `tests/share.test.ts`.
- `npm run build`: passed. The source archive and Vite export were written to `dist/`.
- `npm run test:browser -- --project=chromium`: 12/12 passed. The new test is "landscape phones and touch tablets keep the whole board, start action and direction pad on one screen". It checks 844×390, 852×393, 667×375, 932×430, 1024×768 and 1440×900 with touch. At each size it requires the board, Start and all four directions inside the viewport and no horizontal overflow. It also taps a direction during play.
- The 60-second-run test was racy and failed on the original source too. Clicking Start fetches a fresh board, and the test jumped the clock 60s before the routed response arrived. That tripped the app's 6s API timeout and dropped into demo. The test now waits for the run to start. It also asserts that the result counts use singular nouns for exactly one.
- `node .imd/reads/skills/design-critic/scripts/taste.mjs --out test/scratch/taste`: 16/16 checks passed at 320, 390 and 1440. The 390 screenshot shows the board and Start on the first screen.

## Better Interface coverage for this change

- Layout: the board stays dominant in landscape (about 82% of the viewport height at 390px). The controls are next to the board. There is no horizontal overflow at any measured size.
- UI: direction buttons stay 44×44. Touch targets are not shrunk in the compact mode.
- Typography: no new sizes. The compact mode reuses `--text-base`, `--text-lg` and `--text-xl` from the existing scale.
- Writing: the count nouns now agree with their numbers.
- Accessibility: the d-pad keeps its accessible names. The hidden rail's information is still in the header's Source & data dialog and the footer link, as on portrait phones.
- Colors: unchanged.

## Limitations

- WebKit could not launch on this host because system libraries are missing (libavif, libharfbuzz-icu, libmanette and others). The WebKit project was not run this round.
- No physical phones were tested. `pointer: coarse` was emulated with Playwright `hasTouch`.
- 320×568 portrait (a first-generation iPhone SE size) still puts the d-pad below the fold. The portrait layout was not part of these findings and is unchanged.
- Publishing to GitHub, pinning to IPFS and assigning the ENS label are done outside this worker's run. No URL or CID is claimed.
