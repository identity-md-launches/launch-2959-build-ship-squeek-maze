# Worker validation and design review

Date: 4 November 2026. Scope: the single-page game, its production export, official API integration, ready/loading/play/pause/result states, rules/data/copy dialogs, source download, local records, mobile controls, and offline recovery. This is a worker report, not independent verification.

| Area | Result |
| --- | --- |
| Local implementation and static export | Complete |
| Broken primary interactions after corrections | None observed in the checked flows |
| Product and main action on the first screen at 390px | Yes; screenshot and action bounds recorded |
| Unit tests | 19 passed |
| Chromium browser interaction tests | 11 passed |
| Production build / TypeScript | Passed |
| taste@1 | 16/16 passed |
| Shareable result card | Real 1200×630 PNG verified, plus clipboard/manual-copy paths |
| Six Better Interface domains | Reviewed; coverage and limits below |
| GitHub publication / IPFS pin / ENS assignment | External publication pending; no live identifiers claimed |

## Scope decisions and truthful data

The app is an arcade game, not a dashboard or landing page. No wallet, payment, token, custody, gambling, prizes, admin interface, or fabricated reward was added. Personal scores are explicitly local. The initial screen presents the maze and Start action; help and provenance use progressive disclosure.

The official API exposes settlement hashes rather than a separate hash per Squeek block. To meet round-wide board consistency, the seed uses the latest settled hash **at or before the round boundary**, plus the API round and installation. The latest hash fetched at run start is also retained and shown separately. This is an explicit integration choice, not a fabricated Squeek hash. The API's safe-block round can lag wall time by its confirmation delay. See the README's official-source links and `src/api.ts:107`.

Only current, healthy hardware measurements enable live modifiers. Unsupported schemas, unavailable responses, HTTP/network failures, malformed data and timeouts are exercised. Demo mode has no made-up round/hash/height, no simulated telemetry, and neutral speeds. An unavailable wheel during a live run never swaps the board or silently retains a stale bonus.

## Commands and actual outcomes

| Command | Observed outcome |
| --- | --- |
| `npm test` | Exit 0; 19 passing Node tests. Covers 50 maze seeds, connectivity, boundaries, collectibles, patrols, scoring/clamping/shields/sweeps/deadline, movement modifiers and frame rounding, schemas, stale/simulated/faulted telemetry, network/HTTP/JSON/semantic failures, timeout, Retry-After, storage corruption/denial and round/demo separation. |
| `npm run typecheck` | Exit 0; TypeScript `tsc --noEmit`. |
| `npm run build` | Exit 0; Vite static export plus source ZIP. Build does not rely on scratch files or browser downloads. |
| `PLAYWRIGHT_BROWSERS_PATH=test/scratch/browsers npm run test:browser -- --project=chromium` | Exit 0; 11 tests passed against the production export under `/preview/`. The complete final suite took about 13 seconds. |
| `PLAYWRIGHT_BROWSERS_PATH=test/scratch/browsers IMD_PLAYWRIGHT="$PWD/node_modules/playwright/index.mjs" node .imd/reads/skills/design-critic/scripts/taste.mjs --out test/scratch/taste` | Exit 0; all 16 checks passed. The probe renders 320, 390 and 1440px and reduced motion. The sanitized check record is `artifacts/design-probe.json`. |
| `npm run check:api` | Actual official network responses parsed successfully as live hardware data. Exact public round, hash, state and observation time are in `artifacts/live-api-check.json`. |
| `PLAYWRIGHT_BROWSERS_PATH=test/scratch/browsers npm run capture` | Exit 0; current official data, four screenshots, no script errors or failed local assets, loaded Silkscreen, no horizontal overflow; axe found zero violations in play/result. See `artifacts/visual-check.json`. |
| `npm run check:export` | Exit 0; complete required files and source download, matching manifest/lockfile, relative asset links, real PNG dimensions, no dependency/cache directories, no symlinks or unnecessary archives, below the 8 MiB budget. Exact totals are in `artifacts/export-check.json`. |

The probe input files are provided references and are removed by the assignment after submission; the sanitized results and this coverage record remain. Source, build, unit tests and interaction tests have no dependency on those reference files.

### Meaningful browser flows

The 11 tests cover: production assets and main-action visibility at 320/390/768/1440px; keyboard collection; timer pause/resume; native dialog focus trap and return; refreshing hardware state and neutral speeds on signal loss without changing the board; a full 60-second result using the browser clock; local best persistence and reload; real PNG signature/dimensions; clipboard and selectable-copy fallback; offline-to-live retry; touch pad and trusted Chromium swipe events; rules/data/ready axe scans; reduced-motion transition removal; full hash wrapping and source ZIP download; 200% text enlargement; opening help during a pending start; and a late Retry response arriving after play begins.

Frozen official-response fixtures are isolated to `tests/`; they make browser tests repeatable and are never imported by runtime code. Screenshots instead used current, unmodified official responses fetched during validation. Direct external HTTPS from the sandbox browser returned `net::ERR_EMPTY_RESPONSE`; the local validation driver forwarded official responses to the browser. No proxy or backend is part of the production export. The direct browser failure also exercised the labelled demo screen.

## Better Interface: six-domain coverage

The workflow and core principles for all six domains were read from the pinned Better Interface guide, with focus, hit areas, motion, contrast and design documentation sections consulted as needed. The design-critic reference and its probe were also read and applied. Wallet guidance was read; wallet components are not applicable to this read-only game.

| Domain | Coverage | Evidence and remaining limits |
| --- | --- | --- |
| Accessibility | Checked | Native buttons/links/dialogs, names and roles, keyboard game input, Escape/P, explicit focus wrapping and return, stable polite score announcements, 44px directional controls, visible cyan focus, geometry plus text for status, reduced motion. Targeted axe WCAG A/AA scans of ready/rules/data/play/result report zero violations. Actual screen-reader and physical-device sessions were not performed; the spatial maze does not offer an equivalent nonvisual navigation mode. |
| Layout | Checked | Screenshots at 390 and 1440; automated reflow at 320/390/768/1440; first-screen action verified at 390. Header/HUD wrap under 200% text enlargement. Dialog and overlay overflow remains scrollable; full hashes wrap without ellipsis. Browser-native zoom and translated RTL layouts were not tested; English is implemented. |
| Writing | Checked | Buttons name their actions. Rules shortened to a compact explanation. Live, unknown, stale and demo states are distinct; errors have retry. Scores and storage are described as personal/device-local. Timestamp and settlement provenance are explicit. Publication is not presented as already complete. |
| Typography | Checked | Local Silkscreen is confirmed loaded; system sans for prose, data monospace for hashes, tabular changing figures, six declared size tokens, natural tracking, 400/600 with 700 only on the hazard symbol. Wrapping inspected on final screenshots and at enlarged text. Actual system-font selection varies by OS. |
| Colors | Checked | Semantic tokens, explicit accent/signal/danger roles, readable secondary text, opaque text surfaces. Probe and axe text checks pass; boundary pairs were calculated and strengthened. Measured pairs are below. A light theme is not applicable to this requested dark arcade design. |
| UI details | Checked | Ready/loading/pending/play/pause/result, enabled/disabled/hover/focus, network failure/recovery, storage failure and sharing fallbacks reviewed. No border+shadow cards, gradients, ornamental motion or endless animation. Player/hazard CSS interpolation is removed for reduced motion; essential game steps and pause remain. Browser Animations-panel 10% playback was not performed. |

### Measured contrast

Values use WCAG sRGB relative luminance, calculated from the actual source colors and checked against the computed foreground/background in the rendered game. Text is placed on opaque backgrounds. These are solid-color pair ratios, not claims about individual antialiased edge pixels.

| Foreground / background | Ratio | Use |
| --- | --- | --- |
| `#eef2ef` / `#111619` | 16.12:1 | Main text |
| `#a8b4b7` / `#111619` | 8.57:1 | Secondary text on page |
| `#a8b4b7` / `#1e282d` | 7.07:1 | Modifier/help text on raised surface |
| `#6bddda` / `#1e282d` | 9.29:1 | Signal text on raised surface |
| `#111619` / `#f4d45c` | 12.51:1 | Primary button text |
| `#60747a` / `#131b1f` | 3.55:1 | Maze wall boundary against floor |
| `#60747a` / `#1e282d` | 3.06:1 | Enabled control boundary against raised fill |

## Findings, fixes and rechecks

All listed findings were corrected. Locations point to the final source implementing the fix.

1. **High, API integration: browser fetch receiver.** `src/api.ts:158`, `const fetcher = this.fetcher`. Initially the native fetch was called as a method of the client, which browsers rejected; fixture-driven browser runs reached fallback instead of a live board. Calling the saved function without the client receiver fixes it. Rechecked: live fixture path, real API parsing, full browser suite and live-data screenshot capture pass.
2. **Medium, accessibility: Tab did not wrap at the end of the dialog.** `src/components.tsx:79`, `onKeyDown`. Reproduce by focusing Got it and pressing Tab: the initial native behavior did not return to Close. Added explicit first/last wrapping while retaining native modal inertness, Escape and focus restoration. Rechecked: keyboard focus test and axe scans pass.
3. **High, touch controls: short taps could end before a simulation frame.** `src/App.tsx:275`, `direction.current = d; moveOnce(d)`. Source review showed pointer-down only set a held direction and pointer-up could clear it before any frame. The first legal movement now occurs immediately; continued motion still respects the cooldown. Rechecked: a trusted touch tap changes the hamster position, and swipe/hold paths execute.
4. **Medium, scoring: a floored bump could consume future pickups.** `src/game.ts:27`, event-based `scoreFor`. The initial aggregate formula allowed negative debt behind a displayed zero. Scores now clamp per bump and every new pickup grants 10. Rechecked: score event, collision, shield, sweep, deadline and browser collection tests pass.
5. **Medium, colors: wall/control boundaries were too faint.** `src/components.tsx:47` and `src/styles.css:26`. Initial `#42565c` had only 2.26:1 against the floor and 1.95:1 against raised controls. Replaced the visible boundary token/stroke with `#60747a` (3.55:1 / 3.06:1), keeping subdued dividers separate. Rechecked: final active-maze screenshot and solid-color calculations above.
6. **Medium, layout: enlarged header text pushed a utility outside the viewport.** `src/styles.css:72`, `:87`, `:102`. The 200% test measured the source control beyond the 390px right edge. Header/HUD now wrap, and oversized overlay content can scroll. Rechecked: the 200% test finds no horizontal overflow, no overlapping counter boxes, and successfully reaches Start.
7. **High, state handling: pending requests could resume or reset a run.** `src/App.tsx:144` and `:153`. A Start response arriving after help opened could start the timer behind the dialog; a late ready-screen Retry response could replace an active engine. Start now checks visibility/open dialogs, and Retry applies a board only while still ready. Rechecked: dedicated pending-help and late-Retry interaction tests both pass.
8. **Medium, simulation: rounding could weaken the stated movement bonus.** `src/game.ts:82`, movement cooldown. Resetting a fractional running interval to zero discarded part of each simulation slice. Movement now retains the remainder. Rechecked: a long-corridor test gives the same distance across 1ms versus large frame deltas and stays within one cell of the intended 10% timing.

## Final screenshot review

The final screenshots were opened and visually inspected, not merely generated:

- `artifacts/screenshots/desktop-ready.png`: the maze dominates the cabinet layout; the score row aligns with its edges; the rail shows the real resting state, modifier and public source.
- `artifacts/screenshots/mobile-ready.png`: at 390×844, the product name, maze and yellow Start action are visible without scrolling. The source utility remains named for assistive technology. The capture records the action rectangle inside the first viewport.
- `artifacts/screenshots/mobile-playing.png`: the overlay is gone; the hamster has collected a Squeek and the score/timer updated. The focused board outline is visible; all four touch directions remain available.
- `artifacts/screenshots/mobile-result.png`: a completed 60-second run shows its score, round, local best, Replay, Share result and Save card. No fabricated public ranking or reward is shown.

The probe additionally saves its own 390/1440 viewport/full-page screenshots to disposable scratch space. Its layout checks cover 320px, and motion checks repeat under reduced motion. No observed first-screen or repeated probe failure remains after correction.

## Limits and completion

The supplied browser MCP could not start because its expected Chrome distribution was absent. A separately installed Playwright Chromium successfully provided the rendered and interaction evidence above. WebKit was downloaded but could not launch because the runtime lacks its native graphics/media libraries; Safari/WebKit behavior is **not verified**. No physical phone, native share sheet, screen-reader session, or browser-native 200% zoom session was tested. Clipboard, manual-copy, PNG download, touch emulation and 200% CSS text enlargement were tested instead, without treating them as equivalents to those unavailable checks.

Official API uptime, finality, future schema/deployment changes, and sufficient recent settlement history are outside this client. It reports unavailable data honestly and remains playable in labelled demo mode. Client clock accuracy affects freshness decisions. Personal scores are not tamper resistant and live speed conditions are not a globally fair competition.

**Complete for local implementation, review, testing and static delivery.** Public GitHub publication, IPFS pinning and the `squeek-maze-sprint` ENS site label are prepared for the external publishing step and remain unverified here. See `artifacts/publication.json`. No publication credentials, destination owner, fake repository URL, CID or guessed ENS domain was invented.
